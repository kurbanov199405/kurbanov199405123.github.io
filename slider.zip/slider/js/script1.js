document.addEventListener("DOMContentLoaded", function() {
    const dots1 = document.querySelector("button#slick-slide-control00");
    dots1.innerHTML = '';
});